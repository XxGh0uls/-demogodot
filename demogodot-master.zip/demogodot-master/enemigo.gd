extends Area2D
@onready var imagen_mori = $"../TextureRect"

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:

	print("¡El jugador tocó un enemigo!")
	print("Nombre del cuerpo: ", body.name)
	
	imagen_mori.visible = true
